# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from flask_wtf import FlaskForm
from wtforms import TextField, PasswordField,BooleanField
from wtforms.validators import InputRequired, Email, DataRequired

## login and registration

class LoginForm(FlaskForm):
    username = TextField    ('Username', id='username_login'   , validators=[DataRequired()])
    password = PasswordField('Password', id='pwd_login'        , validators=[DataRequired()])
    #remember_me = BooleanField('Save Details')


class CreateAccountForm(FlaskForm):
    username = TextField('Username'     , id='username_create' , validators=[DataRequired()])
    email    = TextField('Email'        , id='email_create'    , validators=[DataRequired(), Email()])
    password = PasswordField('Password' , id='pwd_create'      , validators=[DataRequired()])


class AddMicrowaveEquipmentForm(FlaskForm) :
    name =          TextField('Username'     , id='name_mvadd' , validators=[DataRequired()])
    ip_address =    TextField('IP Address'     , id='ip_mvadd' , validators=[DataRequired()])
    type =          TextField('Equipment Type'     , id='type_mvadd' , validators=[DataRequired()])
    username =      TextField('Connexion Username'     , id='username_mvadd' , validators=[DataRequired()])
    password =      TextField('Connexion Password'     , id='username_mvadd' , validators=[DataRequired()])
