# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from app.home import blueprint
from flask import render_template, redirect, url_for, request
from flask_login import login_required, current_user
from app import db, login_manager
from jinja2 import TemplateNotFound

#Call forms and models to use
from app.base.forms import AddMicrowaveEquipmentForm
from app.base.models import MicrowaveEquipment

@blueprint.route('/index')
@login_required
def index():
    return render_template('index.html')


@blueprint.route('/getMWEquipments', methods=['GET'])
@login_required
def getMWEquipments() :
    MW = MicrowaveEquipment.query.all()
    return render_template( 'microwaves.html', equipments = MW)
    


#Add or Update
@blueprint.route('/add_MW_equipment', methods=['POST'])
def add_MW_equipment() :

    occur_ = MicrowaveEquipment.query.filter_by(ip_address=request.form['prev_ip']).first()
    #occur_ = MicrowaveEquipment.query.filter_by(id=request.form['id']).first()

    #Cas of update
    if occur_ !=  None :
        db.session.delete(occur_)
    
    equipment = MicrowaveEquipment(name=request.form['name'],ip_address=request.form['ip_address'],type=request.form['type'],username=request.form['username'],password=request.form['password'])

    db.session.add(equipment)
    db.session.commit()
    print('Add/Update Success')

    return 'Add/Update Success'


#Delete MW
@blueprint.route('/del_MW_equipment', methods=['POST'])
def del_MW_equipment() :

    occur_ = MicrowaveEquipment.query.filter_by(ip_address=request.form['ip_address']).first()
    db.session.delete(occur_)
    db.session.commit()
    print('Del Success')

    return 'Del Success'

@blueprint.route('/<template>')
@login_required
def route_template(template):

    try:

        if not template.endswith( '.html' ):
            template += '.html'

        return render_template( template )

    except TemplateNotFound:
        return render_template('page-404.html'), 404
    
    except:
        return render_template('page-500.html'), 500


